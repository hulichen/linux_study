#include<stdio.h>
int main()
{
  printf("didiidididiidiididi\n");
  printf("%d + %d\n",'g','a');




  return 0;
}
